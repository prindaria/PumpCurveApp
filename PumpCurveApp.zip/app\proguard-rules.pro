# Add project specific ProGuard rules here.
-keep class com.github.mikephil.charting.** { *; }
-dontwarn com.github.mikephil.charting.**
