package com.pumpcurve

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.*
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.ValueFormatter
import org.apache.commons.csv.CSVFormat
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : AppCompatActivity() {

    private lateinit var chartMain: LineChart
    private lateinit var listPumps: ListView
    private lateinit var tvCacheInfo: TextView
    private lateinit var btnSelectAll: Button
    private lateinit var btnDeselectAll: Button
    private lateinit var btnInvert: Button
    private lateinit var rbXLinear: RadioButton
    private lateinit var rbXLog: RadioButton
    private lateinit var rbYLinear: RadioButton
    private lateinit var rbYLog: RadioButton
    private lateinit var cbCustomRange: CheckBox
    private lateinit var layoutRange: View
    private lateinit var etXMin: EditText
    private lateinit var etXMax: EditText

    // Data storage
    data class PumpData(val name: String, val pressure: Double, val speed: Double)
    
    private val allPumpData = mutableMapOf<String, MutableList<PumpData>>()
    private val pumpNames = mutableListOf<String>()
    private val selectedPumps = mutableSetOf<String>()
    private val chartColors = intArrayOf(
        Color.RED, Color.BLUE, Color.GREEN, Color.MAGENTA, Color.CYAN,
        Color.parseColor("#FF9800"), Color.parseColor("#9C27B0"),
        Color.parseColor("#00BCD4"), Color.parseColor("#8BC34A"),
        Color.parseColor("#FF5722"), Color.parseColor("#795548"),
        Color.parseColor("#607D8B"), Color.parseColor("#E91E63"),
        Color.parseColor("#3F51B5"), Color.parseColor("#009688")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupChart()
        loadBuiltInData()
        setupEventListeners()
    }

    private fun initViews() {
        chartMain = findViewById(R.id.chartMain)
        listPumps = findViewById(R.id.listPumps)
        tvCacheInfo = findViewById(R.id.tvCacheInfo)
        btnSelectAll = findViewById(R.id.btnSelectAll)
        btnDeselectAll = findViewById(R.id.btnDeselectAll)
        btnInvert = findViewById(R.id.btnInvert)
        rbXLinear = findViewById(R.id.rbXLinear)
        rbXLog = findViewById(R.id.rbXLog)
        rbYLinear = findViewById(R.id.rbYLinear)
        rbYLog = findViewById(R.id.rbYLog)
        cbCustomRange = findViewById(R.id.cbCustomRange)
        layoutRange = findViewById(R.id.layoutRange)
        etXMin = findViewById(R.id.etXMin)
        etXMax = findViewById(R.id.etXMax)

        // Setup X/Y unit spinners
        val xUnitAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, arrayOf("Torr", "Pa", "mbar"))
        xUnitAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        findViewById<Spinner>(R.id.spinnerXUnit).adapter = xUnitAdapter

        val yUnitAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, arrayOf("L/min", "m³/h", "CFM"))
        yUnitAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        findViewById<Spinner>(R.id.spinnerYUnit).adapter = yUnitAdapter
    }

    private fun setupChart() {
        chartMain.apply {
            description.isEnabled = false
            setTouchEnabled(true)
            isDragEnabled = true
            setScaleEnabled(true)
            setPinchZoom(true)
            setDrawGridBackground(false)

            // X Axis (Pressure - default log scale)
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                textSize = 10f
                textColor = Color.DKGRAY
                setDrawGridLines(true)
                gridColor = Color.LTGRAY
                granularity = 1f
                labelRotationAngle = 0f
            }

            // Y Left Axis (Pumping Speed - default log scale)
            axisLeft.apply {
                textSize = 10f
                textColor = Color.DKGRAY
                setDrawGridLines(true)
                gridColor = Color.LTGRAY
                setPosition(YAxis.YAxisLabelPosition.OUTSIDE_CHART)
            }

            axisRight.isEnabled = false

            legend.apply {
                form = Legend.LegendForm.LINE
                textSize = 9f
                verticalAlignment = Legend.LegendVerticalAlignment.TOP
                horizontalAlignment = Legend.LegendHorizontalAlignment.RIGHT
                orientation = Legend.LegendOrientation.VERTICAL
                setDrawInside(true)
                wordWrapEnabled = true
            }
        }
    }

    private fun loadBuiltInData() {
        try {
            val inputStream = assets.open("DATABASE.csv")
            val reader = BufferedReader(InputStreamReader(inputStream))
            
            allPumpData.clear()
            pumpNames.clear()
            
            // Skip header line
            reader.readLine()
            
            var lineCount = 0
            reader.use { r ->
                r.forEachLine { line ->
                    if (line.isBlank()) return@forEachLine
                    try {
                        val parts = line.split(",")
                        if (parts.size >= 3) {
                            val pumpName = parts[0].trim()
                            val pressure = parts[1].trim().toDoubleOrNull() ?: return@forEachLine
                            val speed = parts[2].trim().toDoubleOrNull() ?: return@forEachLine
                            
                            if (!allPumpData.containsKey(pumpName)) {
                                allPumpData[pumpName] = mutableListOf()
                                pumpNames.add(pumpName)
                            }
                            allPumpData[pumpName]!!.add(PumpData(pumpName, pressure, speed))
                            lineCount++
                        }
                    } catch (_: Exception) {}
                }
            }

            // Sort pump names alphabetically
            pumpNames.sortBy { it.lowercase() }

            updateCacheInfo(lineCount)
            populatePumpList()

        } catch (e: Exception) {
            tvCacheInfo.text = "加载数据失败: ${e.message}"
        }
    }

    private fun updateCacheInfo(dataPointCount: Int) {
        val info = "已加载泵型号: ${pumpNames.size} 条\n数据点: $dataPointCount 个"
        tvCacheInfo.text = info
    }

    private fun populatePumpList() {
        val adapter = object : ArrayAdapter<String>(
            this,
            android.R.layout.simple_list_item_multiple_choice,
            pumpNames
        ) {}
        
        listPumps.adapter = adapter
        listPumps.choiceMode = ListView.CHOICE_MODE_MULTIPLE
        
        listPumps.setOnItemClickListener { _, _, position, _ ->
            val name = pumpNames[position]
            if (selectedPumps.contains(name)) {
                selectedPumps.remove(name)
            } else {
                selectedPumps.add(name)
            }
        }
    }

    private fun setupEventListeners() {
        findViewById<Button>(R.id.btnSelectCsv).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("选择数据源")
                .setMessage("当前使用内置 DATABASE.csv 数据。\n\n共 ${pumpNames.size} 个泵型号，${allPumpData.values.sumOf { it.size }} 个数据点。")
                .setPositiveButton("确定", null)
                .show()
        }

        btnSelectAll.setOnClickListener {
            for (i in pumpNames.indices) {
                listPumps.setItemChecked(i, true)
                selectedPumps.add(pumpNames[i])
            }
        }

        btnDeselectAll.setOnClickListener {
            for (i in pumpNames.indices) {
                listPumps.setItemChecked(i, false)
            }
            selectedPumps.clear()
        }

        btnInvert.setOnClickListener {
            for (i in pumpNames.indices) {
                val name = pumpNames[i]
                if (listPumps.isItemChecked(i)) {
                    listPumps.setItemChecked(i, false)
                    selectedPumps.remove(name)
                } else {
                    listPumps.setItemChecked(i, true)
                    selectedPumps.add(name)
                }
            }
        }

        cbCustomRange.setOnCheckedChangeListener { _, isChecked ->
            layoutRange.visibility = if (isChecked) View.VISIBLE else View.GONE
        }

        findViewById<Button>(R.id.btnRefreshChart).setOnClickListener {
            refreshChart()
        }

        findViewById<Button>(R.id.btnReloadData).setOnClickListener {
            selectedPumps.clear()
            loadBuiltInData()
            Toast.makeText(this, "数据已重新加载", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnStandalone).setOnClickListener {
            showStandaloneChartDialog()
        }

        // Auto-refresh on axis type change
        rbXLinear.setOnCheckedChangeListener { _, _ -> refreshChart() }
        rbXLog.setOnCheckedChangeListener { _, _ -> refreshChart() }
        rbYLinear.setOnCheckedChangeListener { _, _ -> refreshChart() }
        rbYLog.setOnCheckedChangeListener { _, _ -> refreshChart() }
    }

    private fun refreshChart() {
        if (selectedPumps.isEmpty()) {
            Toast.makeText(this, "请先选择至少一条曲线", Toast.LENGTH_SHORT).show()
            return
        }

        val lineDataSets = mutableListOf<LineDataSet>()
        var colorIndex = 0

        val sortedSelected = selectedPumps.sortedBy { it.lowercase() }

        for (pumpName in sortedSelected) {
            val dataList = allPumpData[pumpName] ?: continue
            
            // Sort by pressure for proper curve drawing
            val sortedData = dataList.sortedBy { it.pressure }
            
            val entries = sortedData.mapIndexed { index, data ->
                Entry(
                    data.pressure.toFloat(),
                    data.speed.toFloat(),
                    index
                )
            }.toMutableList()

            if (entries.isEmpty()) continue

            val dataSet = LineDataSet(entries, pumpName).apply {
                color = chartColors[colorIndex % chartColors.size]
                setDrawCircles(false)
                lineWidth = 1.8f
                setDrawValues(false)
                mode = LineDataSet.Mode.CUBIC_BEZIER
                cubicIntensity = 0.15f
            }
            
            lineDataSets.add(dataSet)
            colorIndex++
        }

        if (lineDataSets.isEmpty()) {
            Toast.makeText(this, "没有可绘制的数据", Toast.LENGTH_SHORT).show()
            return
        }

        val lineData = LineData(lineDataSets.toTypedArray())
        chartMain.data = lineData

        // Configure axis types
        configureAxes()

        chartMain.invalidate()
    }

    private fun configureAxes() {
        val isXLog = rbXLog.isChecked
        val isYLog = rbYLog.isChecked

        // X Axis configuration
        chartMain.xAxis.apply {
            if (isXLog) {
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(value: Float): String {
                        return if (value > 0) String.format("%.4g", value.toDouble()) else ""
                    }
                }
                axisMinimum = 0.001f
                axisMaximum = if (cbCustomRange.isChecked && etXMax.text.isNotEmpty()) {
                    etXMax.text.toString().toFloatOrNull() ?: 1000f
                } else {
                    1000f
                }
            } else {
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(value: Float): String {
                        return String.format("%.2f", value.toDouble())
                    }
                }
                axisMinimum = 0f
                axisMaximum = if (cbCustomRange.isChecked && etXMax.text.isNotEmpty()) {
                    etXMax.text.toString().toFloatOrNull() ?: 800f
                } else {
                    800f
                }
            }
        }

        // Y Axis configuration
        chartMain.axisLeft.apply {
            if (isYLog) {
                axisMinimum = 0.1f
                axisMaximum = 200000f
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(value: Float): String {
                        return if (value > 0) String.format("%.0f", value.toDouble()) else ""
                    }
                }
            } else {
                axisMinimum = 0f
                axisMaximum = 100000f
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(value: Float): String {
                        return String.format("%.0f", value.toDouble())
                    }
                }
            }
        }
    }

    private fun showStandaloneChartDialog() {
        if (selectedPumps.isEmpty()) {
            Toast.makeText(this, "请先选择曲线并刷新图表", Toast.LENGTH_SHORT).show()
            return
        }

        val dialogView = layoutInflater.inflate(R.layout.activity_main, null)
        val standaloneChart = dialogView.findViewById<LineChart>(R.id.chartMain)
        
        // Hide left panel in standalone view
        dialogView.findViewById<View>(R.id.chartMain)?.let { chart ->
            // The chart is already there, just copy settings
        }

        AlertDialog.Builder(this)
            .setTitle("独立图表视图 (${selectedPumps.size} 条曲线)")
            .setView(dialogView)
            .setPositiveButton("关闭", null)
            .create()
            .apply {
                window?.setLayout(
                    (resources.displayMetrics.widthPixels * 0.95).toInt(),
                    (resources.displayMetrics.heightPixels * 0.85).toInt()
                )
                show()
                
                // Copy current chart to standalone after dialog is shown
                standaloneChart?.data = chartMain.data?.clone()
                standaloneChart?.xAxis = chartMain.xAxis.clone()
                standaloneChart?.axisLeft = chartMain.axisLeft.clone()
                standaloneChart?.legend = chartMain.legend.clone()
                standaloneChart?.invalidate()
            }
    }
}
